Code for the conduction welding setup at TPRC, designed built and coded by Mathieu Naus

This code controlls reads the temperatures, controlls the heaters, the pressure-actuator, the coolers and the linear actuator

All code is in the src/main.cpp file as I did not feel like dividing everything into sub-files/classes.

If you have to read this and use the code: good luck